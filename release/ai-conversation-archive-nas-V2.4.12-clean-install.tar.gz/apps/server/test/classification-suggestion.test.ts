import { describe, expect, it } from "vitest";
import {
  classificationCandidateReason,
  isLikelyOverSpecificProjectName,
  isRecoverableClassificationAiError,
  parseClassificationSuggestion,
  parseTagSuggestions,
  projectRelevanceScore,
  selectRelevantProjects,
  shouldReuseClassification,
} from "../src/services/analysis.js";

const projectRows = [
  {
    id: "11111111-1111-1111-1111-111111111111",
    name: "腾讯元宝采集",
    description: "",
  },
  {
    id: "22222222-2222-2222-2222-222222222222",
    name: "OpenClaw 同步",
    description: "",
  },
];

describe("parseClassificationSuggestion", () => {
  it("accepts a top-level suggestion object and resolves project names", () => {
    const result = parseClassificationSuggestion(
      {
        existingProjectId: "腾讯元宝采集",
        confidence: "80%",
        rationale: "同一采集问题",
      },
      projectRows,
    );

    expect(result.existingProjectId).toBe("11111111-1111-1111-1111-111111111111");
    expect(result.confidence).toBe(0.8);
  });

  it("accepts string suggestions from OpenAI-compatible models", () => {
    const result = parseClassificationSuggestion(
      { suggestion: "OpenClaw 同步" },
      projectRows,
    );

    expect(result.suggestedName).toBe("OpenClaw 同步");
    expect(result.existingProjectId).toBe("22222222-2222-2222-2222-222222222222");
    expect(result.confidence).toBe(0.65);
  });

  it("keeps suggested names even when there is no existing project match", () => {
    const result = parseClassificationSuggestion(
      {
        suggestion: {
          suggested_project_name: "千问采集修复",
          score: 0.52,
        },
      },
      projectRows,
    );

    expect(result.suggestedName).toBe("千问采集修复");
    expect(result.existingProjectId).toBeNull();
    expect(result.confidence).toBe(0.52);
  });
});

describe("parseTagSuggestions", () => {
  it("normalizes, deduplicates, filters, and caps model tag suggestions", () => {
    const result = parseTagSuggestions({
      tags: [
        { name: " TypeScript ", confidence: 0.7 },
        { name: "ＴｙｐｅＳｃｒｉｐｔ", confidence: 0.9 },
        { name: "一次性的完整句子！", confidence: 0.99 },
        { name: "低置信", confidence: 0.2 },
      ],
    });
    expect(result).toEqual([{ name: "TypeScript", confidence: 0.9 }]);
  });

  it("resolves existing tag ids to names and drops unknown UUID labels", () => {
    const existingTag = {
      id: "b7aff412-0230-43e2-b893-2ad7d567fe36",
      name: "Chrome扩展",
    };
    const result = parseTagSuggestions(
      {
        tags: [
          { name: existingTag.id, confidence: 0.9 },
          { tagId: existingTag.id, confidence: 0.8 },
          { name: "18d0da13-1278-47fc-842d-2587d7ed88cf", confidence: 0.99 },
        ],
      },
      [existingTag],
    );

    expect(result).toEqual([{ name: "Chrome扩展", confidence: 0.9 }]);
  });
});

describe("project candidate relevance", () => {
  const candidates = [
    {
      id: "33333333-3333-3333-3333-333333333333",
      name: "生活消费与饮食出行",
      description: "杭州周边自驾、民宿、美食与旅行规划",
    },
    {
      id: "44444444-4444-4444-4444-444444444444",
      name: "高性能服务器采购配置与预算评估",
      description: "GPU、CPU、DDR5、NVMe、RAID 与服务器电源配置",
    },
    ...projectRows,
  ];
  const material = {
    title: "Qwen3.5 本地部署配置评估",
    text: "评估双路 CPU、DDR5、GPU、NVMe RAID 和服务器电源配置。",
  };

  it("keeps semantically related infrastructure projects and removes unrelated lifestyle projects", () => {
    const selected = selectRelevantProjects(material, candidates);
    expect(selected.map((project) => project.id)).toContain("44444444-4444-4444-4444-444444444444");
    expect(selected.map((project) => project.id)).not.toContain("33333333-3333-3333-3333-333333333333");
    expect(projectRelevanceScore(material, candidates[1]!)).toBeGreaterThan(0);
    expect(projectRelevanceScore(material, candidates[0]!)).toBe(0);
  });

  it("caps the model candidate list", () => {
    const many = Array.from({ length: 120 }, (_, index) => ({
      id: `${index}`,
      name: `GPU服务器${index}`,
      description: "GPU服务器",
    }));
    expect(selectRelevantProjects(material, many)).toHaveLength(80);
  });
});

describe("project granularity", () => {
  it("detects over-specific one-off project names", () => {
    expect(
      isLikelyOverSpecificProjectName(
        "ThinkPad跨代型号CPU与内存性能对比咨询",
        "ThinkPad跨代型号CPU与内存性能对比咨询",
      ),
    ).toBe(true);
    expect(isLikelyOverSpecificProjectName("网络安全与系统运维")).toBe(false);
  });


});

describe("shouldReuseClassification", () => {
  const revisionCapturedAt = new Date("2026-07-25T00:00:00.000Z");

  it("reuses a stable economy-mode assignment captured after the latest revision", () => {
    expect(
      shouldReuseClassification({
        mode: "economy",
        reuseStable: true,
        projectId: "11111111-1111-1111-1111-111111111111",
        confidence: 0.8,
        assignmentUpdatedAt: new Date("2026-07-25T00:01:00.000Z"),
        revisionCapturedAt,
      }),
    ).toBe(true);
  });

  it("does not reuse when confidence is low, reuse is disabled, or full mode is requested", () => {
    const stableInput = {
      mode: "economy" as const,
      reuseStable: true,
      projectId: "11111111-1111-1111-1111-111111111111",
      confidence: 0.77,
      assignmentUpdatedAt: new Date("2026-07-25T00:01:00.000Z"),
      revisionCapturedAt,
    };

    expect(shouldReuseClassification(stableInput)).toBe(false);
    expect(
      shouldReuseClassification({ ...stableInput, confidence: 0.8, reuseStable: false }),
    ).toBe(false);
    expect(
      shouldReuseClassification({ ...stableInput, confidence: 0.8, mode: "full" }),
    ).toBe(false);
  });
});

describe("classificationCandidateReason", () => {
  const revisionCapturedAt = new Date("2026-07-25T00:00:00.000Z");
  const freshAssignmentAt = new Date("2026-07-25T00:01:00.000Z");
  const staleAssignmentAt = new Date("2026-07-24T23:59:00.000Z");

  it("invalidates a stable result when an older capture changes the same archive after classification", () => {
    const archiveUpdatedAt = new Date("2026-07-25T00:02:00.000Z");
    const input = { projectId: "project", confidence: 0.95, assignmentUpdatedAt: freshAssignmentAt, revisionCapturedAt, archiveUpdatedAt };
    expect(shouldReuseClassification({ ...input, mode: "economy", reuseStable: true })).toBe(false);
    expect(classificationCandidateReason({ ...input, scope: "incremental", tagCount: 1 })).toBe("changed");
    expect(shouldReuseClassification({ ...input, mode: "economy", reuseStable: true, assignmentUpdatedAt: archiveUpdatedAt })).toBe(true);
  });

  it("marks all rows as candidates for explicit full re-evaluation", () => {
    expect(
      classificationCandidateReason({
        scope: "all",
        projectId: "11111111-1111-1111-1111-111111111111",
        confidence: 0.95,
        assignmentUpdatedAt: freshAssignmentAt,
        revisionCapturedAt,
      }),
    ).toBe("full");
  });

  it("selects unassigned, low-confidence, and changed conversations incrementally", () => {
    expect(
      classificationCandidateReason({
        scope: "incremental",
        projectId: null,
        confidence: null,
        assignmentUpdatedAt: null,
        revisionCapturedAt,
      }),
    ).toBe("unassigned");
    expect(
      classificationCandidateReason({
        scope: "incremental",
        projectId: "11111111-1111-1111-1111-111111111111",
        confidence: 0.77,
        assignmentUpdatedAt: freshAssignmentAt,
        revisionCapturedAt,
      }),
    ).toBe("low_confidence");
    expect(
      classificationCandidateReason({
        scope: "incremental",
        projectId: "11111111-1111-1111-1111-111111111111",
        confidence: 0.8,
        assignmentUpdatedAt: staleAssignmentAt,
        revisionCapturedAt,
      }),
    ).toBe("changed");
  });

  it("selects an existing project that has not received V2.1 tags", () => {
    expect(
      classificationCandidateReason({
        scope: "incremental",
        projectId: "11111111-1111-1111-1111-111111111111",
        tagCount: 0,
        confidence: 0.9,
        assignmentUpdatedAt: freshAssignmentAt,
        revisionCapturedAt,
      }),
    ).toBe("missing_tags");
  });

  it("skips stable fresh assignments in incremental mode", () => {
    expect(
      classificationCandidateReason({
        scope: "incremental",
        projectId: "11111111-1111-1111-1111-111111111111",
        confidence: 0.8,
        assignmentUpdatedAt: freshAssignmentAt,
        revisionCapturedAt,
      }),
    ).toBeNull();
  });
});

describe("isRecoverableClassificationAiError", () => {
  it("treats provider sensitive-input rejections as recoverable for one conversation", () => {
    const error = Object.assign(new Error("422 input new_sensitive (1026)"), {
      status: 422,
    });

    expect(isRecoverableClassificationAiError(error)).toBe(true);
  });

  it("reads sensitive-input rejections from OpenAI-compatible response bodies", () => {
    expect(
      isRecoverableClassificationAiError({
        response: {
          status: 400,
          data: { error: { code: 1026, message: "input new_sensitive" } },
        },
      }),
    ).toBe(true);
  });

  it("treats malformed model JSON as recoverable for classification", () => {
    expect(
      isRecoverableClassificationAiError(
        new Error("Model did not return valid JSON"),
      ),
    ).toBe(true);
  });

  it("does not hide unrelated configuration failures", () => {
    expect(
      isRecoverableClassificationAiError(
        new Error("OpenAI-compatible analysis model is not configured"),
      ),
    ).toBe(false);
  });
});
