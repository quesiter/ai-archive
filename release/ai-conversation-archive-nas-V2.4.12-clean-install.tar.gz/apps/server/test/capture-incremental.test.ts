import type { CaptureDeltaV1, CaptureMessage, CaptureSnapshotV1 } from "@ai-archive/contracts";
import { describe, expect, it, vi } from "vitest";

vi.mock("../src/db.js", () => ({ db: {} }));

const baseMessages: CaptureMessage[] = [
  {
    ordinal: 0,
    externalMessageId: "u1",
    role: "user",
    segments: [{ type: "text", content: "Question" }],
  },
  {
    ordinal: 1,
    externalMessageId: "a1",
    role: "assistant",
    segments: [{ type: "text", content: "Answer" }],
  },
];

const baseRevision = {
  id: "11111111-1111-1111-1111-111111111111",
  completeness: "complete",
  branchFingerprint: "branch-fingerprint-1",
  messageCount: 2,
  contentIntegrityHash: "a".repeat(64),
};

function delta(overrides: Partial<CaptureDeltaV1> = {}): CaptureDeltaV1 {
  return {
    schemaVersion: 1,
    captureMode: "append",
    provider: "chatgpt",
    sessionId: "session-1",
    branchFingerprint: "branch-fingerprint-1",
    adapterVersion: "1.2.1",
    capturedAt: "2026-07-25T04:00:00.000Z",
    triggerReason: "new_messages",
    baseRevisionId: baseRevision.id,
    baseContentHash: baseRevision.contentIntegrityHash,
    baseMessageCount: 2,
    baseLastMessageId: "a1",
    appendedMessages: [
      {
        ordinal: 2,
        externalMessageId: "u2",
        role: "user",
        segments: [{ type: "text", content: "Follow up" }],
      },
      {
        ordinal: 3,
        externalMessageId: "a2",
        role: "assistant",
        segments: [{ type: "text", content: "Second answer" }],
      },
    ],
    ...overrides,
  };
}

describe("incremental capture validation", () => {
  it("requires the exact mutable content baseline, even when the stable revision ID and count still match", async () => {
    const { validateDeltaBase } = await import("../src/services/capture.js");
    for (const baseContentHash of [undefined, "b".repeat(64)]) {
      expect(() => validateDeltaBase({ delta: delta({ baseContentHash }), baseRevision: baseRevision as never, baseMessages }))
        .toThrow(/content baseline/);
    }
  });
  it("backfills parent metadata with an empty delta without changing revision identity", async () => {
    const { mergedSnapshotFromDelta, revisionIdentityHash, snapshotHash, contentIntegrityHash, validateDeltaBase } =
      await import("../src/services/capture.js");
    const input = {
      delta: delta({ parentSessionId: "parent-session", appendedMessages: [] }),
      baseRevision: baseRevision as never,
      baseMessages,
    };
    expect(() => validateDeltaBase(input)).not.toThrow();
    const snapshot = mergedSnapshotFromDelta(input);
    const { parentSessionId, ...withoutParent } = snapshot;
    expect(parentSessionId).toBe("parent-session");
    expect(snapshot.messages).toEqual(baseMessages);
    expect(snapshotHash(snapshot)).toBe(snapshotHash(withoutParent));
    expect(revisionIdentityHash(snapshot)).toBe(revisionIdentityHash(withoutParent));
    expect(contentIntegrityHash(snapshot)).toBe(contentIntegrityHash(withoutParent));
    const withReason = mergedSnapshotFromDelta({
      ...input,
      baseRevision: { ...baseRevision, completenessReason: "Read from local Codex session" } as never,
    });
    expect(withReason.completeness.reason).toBe("Read from local Codex session");
  });

  it("keeps current idempotency strict but bypasses unverifiable legacy hashes", async () => {
    const { captureIdempotencyReplayMode } = await import("../src/services/capture.js");
    expect(captureIdempotencyReplayMode({
      previousSnapshotHash: "snapshot-a",
      previousPayloadIdentityHash: "identity-a",
      currentSnapshotHash: "snapshot-a",
      currentRevisionIdentityHash: "identity-b",
    })).toBe("conflict");
    expect(captureIdempotencyReplayMode({
      previousSnapshotHash: "legacy-a",
      previousPayloadIdentityHash: null,
      currentSnapshotHash: "normalized-b",
      currentRevisionIdentityHash: "identity-b",
    })).toBe("legacy_bypass");
    expect(captureIdempotencyReplayMode({
      previousSnapshotHash: "snapshot-a",
      previousPayloadIdentityHash: null,
      currentSnapshotHash: "snapshot-a",
      currentRevisionIdentityHash: "identity-b",
    })).toBe("replay");
  });

  it("records title changes while keeping recapture timestamps idempotent", async () => {
    const { revisionIdentityHash, snapshotHash } = await import("../src/services/capture.js");
    const snapshot: CaptureSnapshotV1 = {
      schemaVersion: 1,
      provider: "chatgpt",
      sessionId: "session-1",
      branchFingerprint: "branch-fingerprint-1",
      title: "Old title",
      adapterVersion: "1.2.1",
      capturedAt: "2026-07-25T04:00:00.000Z",
      captureMode: "full",
      completeness: {
        status: "complete",
        topReached: true,
        bottomReached: true,
        stable: true,
      },
      messages: baseMessages,
    };

    expect(snapshotHash({ ...snapshot, capturedAt: "2026-07-25T05:00:00.000Z" }))
      .toBe(snapshotHash(snapshot));
    expect(revisionIdentityHash({ ...snapshot, capturedAt: "2026-07-25T05:00:00.000Z" }))
      .toBe(revisionIdentityHash(snapshot));
    expect(revisionIdentityHash({ ...snapshot, title: "New title" }))
      .not.toBe(revisionIdentityHash(snapshot));
    expect(revisionIdentityHash({ ...snapshot, canonicalUrl: "https://example.com/new" }))
      .not.toBe(revisionIdentityHash(snapshot));
  });

  it("accepts a valid append delta but stores only its new message body", async () => {
    const {
      mergedSnapshotFromDelta,
      revisionStorageBody,
      snapshotHash,
      validateDeltaBase,
    } = await import(
      "../src/services/capture.js"
    );
    const input = {
      delta: delta(),
      baseRevision: baseRevision as never,
      baseMessages,
    };

    expect(() => validateDeltaBase(input)).not.toThrow();
    const merged = mergedSnapshotFromDelta(input);

    expect(merged.captureMode).toBe("append");
    expect(merged.baseRevisionId).toBe(baseRevision.id);
    expect(merged.messages.map((message) => message.ordinal)).toEqual([0, 1, 2, 3]);
    expect(revisionStorageBody(input.delta, merged)).toMatchObject({
      storageKind: "delta",
      storedMessages: input.delta.appendedMessages,
    });
    expect(snapshotHash(merged)).toBe(snapshotHash({ ...merged }));
  });

  it("keeps full captures as independently readable snapshots", async () => {
    const { revisionStorageBody } = await import("../src/services/capture.js");
    const snapshot: CaptureSnapshotV1 = {
      schemaVersion: 1,
      provider: "chatgpt",
      sessionId: "session-1",
      branchFingerprint: "branch-fingerprint-1",
      adapterVersion: "1.2.1",
      capturedAt: "2026-07-25T04:00:00.000Z",
      captureMode: "full",
      completeness: {
        status: "complete",
        topReached: true,
        bottomReached: true,
        stable: true,
      },
      messages: baseMessages,
    };

    expect(revisionStorageBody(snapshot, snapshot)).toMatchObject({
      storageKind: "snapshot",
      storedMessages: baseMessages,
    });
  });

  it("merges incremental usage into the base cumulative total", async () => {
    const { cumulativeTokenUsage } = await import("../src/services/capture.js");
    expect(
      cumulativeTokenUsage({
        base: {
          scope: "cumulative",
          inputTokens: 100,
          cachedInputTokens: 50,
          cacheWriteInputTokens: 10,
          outputTokens: 20,
          reasoningOutputTokens: 5,
          totalTokens: 180,
        },
        next: {
          scope: "incremental",
          inputTokens: 40,
          cachedInputTokens: 30,
          cacheWriteInputTokens: 0,
          outputTokens: 10,
          reasoningOutputTokens: 3,
          totalTokens: 80,
        },
      }),
    ).toEqual({
      scope: "cumulative",
      inputTokens: 140,
      cachedInputTokens: 80,
      cacheWriteInputTokens: 10,
      outputTokens: 30,
      reasoningOutputTokens: 8,
      totalTokens: 260,
    });
  });

  it("redacts secrets from captured content and URLs before hashing or storage", async () => {
    const { sanitizeCapturePayloadForStorage } = await import(
      "../src/services/capture.js"
    );
    const snapshot: CaptureSnapshotV1 = {
      schemaVersion: 1,
      provider: "codex",
      sessionId: "secret-session",
      branchFingerprint: "branch-fingerprint-secret",
      title: "Deploy password=DemoOnly_123",
      canonicalUrl: "https://example.com/task?access_token=DemoOnlyToken",
      adapterVersion: "codex-jsonl-v2",
      capturedAt: "2026-08-22T04:00:00.000Z",
      captureMode: "import",
      completeness: {
        status: "complete",
        topReached: true,
        bottomReached: true,
        stable: true,
      },
      messages: [
        {
          ordinal: 0,
          role: "user",
          segments: [
            {
              type: "text",
              content: "password=DemoOnly_123",
              href: "https://example.com/log?api_key=DemoOnlyKey",
            },
          ],
        },
      ],
    };

    const sanitized = sanitizeCapturePayloadForStorage(snapshot) as CaptureSnapshotV1;

    expect(sanitized.title).not.toContain("DemoOnly_123");
    expect(sanitized.canonicalUrl).not.toContain("DemoOnlyToken");
    expect(sanitized.messages[0]?.segments[0]?.content).not.toContain("DemoOnly_123");
    expect(sanitized.messages[0]?.segments[0]?.href).not.toContain("DemoOnlyKey");
  });

  it("bounds revision search text without dropping the archived messages", async () => {
    const {
      buildRevisionSearchText,
      databaseSafeSegmentContent,
      REVISION_SEARCH_TEXT_LIMIT,
      REVISION_SEARCH_TEXT_MESSAGE_LIMIT,
      storedMessageTextStats,
    } = await import("../src/services/capture.js");
    const largeMessages: CaptureMessage[] = [
      {
        ordinal: 0,
        role: "user",
        segments: [{ type: "text", content: "needle prompt" }],
      },
      {
        ordinal: 1,
        role: "tool",
        segments: [{ type: "text", content: "tool-output ".repeat(30_000) }],
      },
      ...Array.from({ length: 80 }, (_, index) => ({
        ordinal: index + 2,
        role: "assistant" as const,
        segments: [
          {
            type: "text" as const,
            content: `assistant-${index} ${"long-answer ".repeat(500)}`,
          },
        ],
      })),
    ];

    const searchText = buildRevisionSearchText(largeMessages);

    expect(REVISION_SEARCH_TEXT_LIMIT).toBeLessThanOrEqual(2_048);
    expect(searchText.length).toBeLessThanOrEqual(REVISION_SEARCH_TEXT_LIMIT);
    expect(searchText).toContain("needle prompt");
    expect(searchText).toContain("search index bounded");
    expect(searchText).toContain("tool messages not indexed");
    expect(searchText).not.toContain("tool-output");

    const safeToolText = databaseSafeSegmentContent({
      type: "tool_status",
      content: "Finding: ENCRYPTION_KEY=\u001b[1;3;mREDACTED\u001b[0m\u0000\u0005done",
    });
    expect(safeToolText).toBe("Finding: ENCRYPTION_KEY=REDACTEDdone");
    expect(safeToolText).not.toMatch(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/);
    expect(
      storedMessageTextStats([
        {
          ordinal: 0,
          role: "assistant",
          segments: [
            { type: "text", content: "正文😀" },
            { type: "reasoning", content: "思考" },
          ],
        },
        {
          ordinal: 1,
          role: "tool",
          segments: [{ type: "text", content: "结果" }],
        },
      ]),
    ).toEqual({ textUnits: 7, reasoningTextUnits: 2, toolTextUnits: 2 });
  });

  it("hashes the exact truncated representation that archive verification reconstructs", async () => {
    const {
      contentIntegrityHash,
      MESSAGE_SEGMENT_CONTENT_LIMIT,
      normalizeCaptureMessagesForStorage,
      snapshotHash,
    } = await import("../src/services/capture.js");
    const oversized = "prefix " + "x".repeat(MESSAGE_SEGMENT_CONTENT_LIMIT + 5_000) + " suffix";
    const snapshot: CaptureSnapshotV1 = {
      schemaVersion: 1,
      provider: "codex",
      sessionId: "oversized-session",
      branchFingerprint: "oversized-branch",
      adapterVersion: "codex-jsonl-v2",
      capturedAt: "2026-08-27T04:00:00.000Z",
      captureMode: "import",
      completeness: {
        status: "complete",
        topReached: true,
        bottomReached: true,
        stable: true,
      },
      messages: [
        {
          ordinal: 0,
          role: "assistant",
          segments: [{ type: "text", content: oversized }],
        },
      ],
    };

    const normalized = normalizeCaptureMessagesForStorage(snapshot.messages);
    expect(normalized[0]?.segments[0]?.content.length).toBe(
      MESSAGE_SEGMENT_CONTENT_LIMIT,
    );
    expect(normalized[0]?.segments[0]?.content).toContain("characters omitted");
    expect(normalizeCaptureMessagesForStorage(normalized)).toEqual(normalized);
    expect(snapshotHash({ ...snapshot, messages: normalized })).not.toBe(
      snapshotHash(snapshot),
    );
    expect(snapshotHash({ ...snapshot, messages: normalized })).toBe(
      snapshotHash({
        ...snapshot,
        messages: normalizeCaptureMessagesForStorage(normalized),
      }),
    );
    expect(contentIntegrityHash({ ...snapshot, messages: normalized })).toBe(
      contentIntegrityHash({
        ...snapshot,
        capturedAt: "2026-08-27T12:00:00+08:00",
        messages: normalizeCaptureMessagesForStorage(normalized),
      }),
    );
  });

  it("keeps Codex import search text small enough for trigram indexing", async () => {
    const { buildRevisionSearchText, REVISION_SEARCH_TEXT_LIMIT } = await import(
      "../src/services/capture.js"
    );
    const longToolOutput = JSON.stringify({
      command: "Get-ChildItem -Recurse",
      output: "line ".repeat(80_000),
    });
    const codexMessages: CaptureMessage[] = [
      {
        ordinal: 0,
        role: "user",
        segments: [
          {
            type: "text",
            content:
              "<environment_context><cwd>F:\\AI_IDE\\CamOps</cwd><shell>powershell</shell></environment_context>\n在本地创建测试环境，并填充300条mock数据",
          },
        ],
      },
      ...Array.from({ length: 268 }, (_, index) => ({
        ordinal: index + 1,
        role: index % 3 === 0 ? ("tool" as const) : ("assistant" as const),
        segments: [
          {
            type: index % 3 === 0 ? ("tool_status" as const) : ("text" as const),
            content:
              index % 3 === 0
                ? longToolOutput
                : `assistant ${index} ${"mock data ".repeat(2_000)}`,
          },
        ],
      })),
    ];

    const searchText = buildRevisionSearchText(codexMessages);

    expect(searchText.length).toBeLessThanOrEqual(REVISION_SEARCH_TEXT_LIMIT);
    expect(searchText).toContain("CamOps");
    expect(searchText).toContain("search index bounded");
    expect(searchText).toContain("tool messages not indexed");
    expect(searchText).not.toContain("Get-ChildItem");
    expect(searchText).not.toContain("line ");
  });

  it("rejects wrong base count, wrong base last ID, duplicate IDs, and non-contiguous ordinals", async () => {
    const { validateDeltaBase } = await import("../src/services/capture.js");
    const input = (candidate: CaptureDeltaV1) => ({
      delta: candidate,
      baseRevision: baseRevision as never,
      baseMessages,
    });

    expect(() => validateDeltaBase(input(delta({ baseMessageCount: 3 })))).toThrow(
      /message count/,
    );
    expect(() => validateDeltaBase(input(delta({ baseLastMessageId: "other" })))).toThrow(
      /last message ID/,
    );
    expect(() =>
      validateDeltaBase(
        input(
          delta({
            appendedMessages: [
              {
                ordinal: 2,
                externalMessageId: "a1",
                role: "assistant",
                segments: [{ type: "text", content: "duplicate" }],
              },
            ],
          }),
        ),
      ),
    ).toThrow(/duplicate/);
    expect(() =>
      validateDeltaBase(
        input(
          delta({
            appendedMessages: [
              {
                ordinal: 4,
                externalMessageId: "a3",
                role: "assistant",
                segments: [{ type: "text", content: "gap" }],
              },
            ],
          }),
        ),
      ),
    ).toThrow(/contiguous/);
  });

  it("rejects partial base revisions and branch mismatches", async () => {
    const { validateDeltaBase } = await import("../src/services/capture.js");

    expect(() =>
      validateDeltaBase({
        delta: delta(),
        baseRevision: { ...baseRevision, completeness: "partial" } as never,
        baseMessages,
      }),
    ).toThrow(/Partial/);
    expect(() =>
      validateDeltaBase({
        delta: delta({ branchFingerprint: "different-branch" }),
        baseRevision: baseRevision as never,
        baseMessages,
      }),
    ).toThrow(/branch/);
  });
});
