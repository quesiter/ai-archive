#!/bin/sh
set -eu

case "${1:-}" in
  help|-h|--help)
    cat <<'EOF'
AI Conversation Archive macOS local sync

Usage:
  sh sync-local-macos.sh              Backfill all safe local history, then watch future changes.
  sh sync-local-macos.sh rebuild-only Backfill all safe local history once.
  sh sync-local-macos.sh resync-safe  Reset local sync state, then backfill all safe local history once.
  sh sync-local-macos.sh recent-only  Import only recent safe history once.
  sh sync-local-macos.sh watch-only   Watch future changes without an initial scan.
  sh sync-local-macos.sh full-rebuild Explicit full import without safety limits.

Environment overrides:
  AI_ARCHIVE_SERVER=https://ai-archive.gyee.tech:18443
  AI_ARCHIVE_CODEX_ROOT=$HOME/.codex
  AI_ARCHIVE_OPENCLAW_ROOT=$HOME/.openclaw
  AI_ARCHIVE_CLAUDE_CODE_ROOT=$HOME/.claude
  AI_ARCHIVE_SYNC_CONFIG=$HOME/.config/ai-archive/openclaw-sync.json
  AI_ARCHIVE_SAFE_RECENT_DAYS=14
  AI_ARCHIVE_SAFE_MAX_FILES=500
  AI_ARCHIVE_SAFE_MAX_FILE_MB=50
  AI_ARCHIVE_SAFE_MAX_MESSAGES=12000
  AI_ARCHIVE_SYNC_DELAY_MS=750
EOF
    exit 0
    ;;
esac

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
AGENT="$ROOT/openclaw-sync.cjs"
if [ ! -f "$AGENT" ]; then
  echo "Missing sync agent: $AGENT" >&2
  echo "Copy the whole extracted folder; do not copy this script alone." >&2
  exit 1
fi

SERVER_URL=${AI_ARCHIVE_SERVER:-"https://ai-archive.gyee.tech:18443"}
CONFIG_PATH=${AI_ARCHIVE_SYNC_CONFIG:-"$HOME/.config/ai-archive/openclaw-sync.json"}
CODEX_ROOT=${AI_ARCHIVE_CODEX_ROOT:-"$HOME/.codex"}
OPENCLAW_ROOT=${AI_ARCHIVE_OPENCLAW_ROOT:-"$HOME/.openclaw"}
CLAUDE_CODE_ROOT=${AI_ARCHIVE_CLAUDE_CODE_ROOT:-}
if [ -z "$CLAUDE_CODE_ROOT" ] && [ -d "$HOME/.claude" ]; then
  CLAUDE_CODE_ROOT="$HOME/.claude"
fi

SAFE_RECENT_DAYS=${AI_ARCHIVE_SAFE_RECENT_DAYS:-14}
SAFE_MAX_FILES=${AI_ARCHIVE_SAFE_MAX_FILES:-500}
SAFE_MAX_FILE_MB=${AI_ARCHIVE_SAFE_MAX_FILE_MB:-50}
SAFE_MAX_MESSAGES=${AI_ARCHIVE_SAFE_MAX_MESSAGES:-12000}
SAFE_DELAY_MS=${AI_ARCHIVE_SYNC_DELAY_MS:-750}
export AI_ARCHIVE_SYNC_CONFIG="$CONFIG_PATH"
export NODE_OPTIONS="--max-old-space-size=4096 ${NODE_OPTIONS:-}"

SAFE_BACKFILL_ARGS="--recent-days 0 --max-files 0 --max-file-mb $SAFE_MAX_FILE_MB --max-messages $SAFE_MAX_MESSAGES --delay-ms $SAFE_DELAY_MS"
RECENT_ARGS="--recent-days $SAFE_RECENT_DAYS --max-files $SAFE_MAX_FILES --max-file-mb $SAFE_MAX_FILE_MB --max-messages $SAFE_MAX_MESSAGES --delay-ms $SAFE_DELAY_MS"

echo
echo "AI Conversation Archive - macOS local sync"
echo "Folder : $ROOT"
echo "Server : $SERVER_URL"
echo "Codex  : $CODEX_ROOT"
echo "OpenClaw: $OPENCLAW_ROOT"
echo "Config : $CONFIG_PATH"
echo "Backfill safety: all dates, unlimited files, max ${SAFE_MAX_FILE_MB} MB/file, max ${SAFE_MAX_MESSAGES} messages/session"
echo

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js was not found. Install Node.js 22 or newer first." >&2
  echo "Recommended: brew install node@22, or download from https://nodejs.org/" >&2
  exit 1
fi

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || true)
if [ -z "$NODE_MAJOR" ] || [ "$NODE_MAJOR" -lt 22 ]; then
  echo "Node.js 22 or newer is required. Current version: $(node -v 2>/dev/null || echo unknown)" >&2
  exit 1
fi

if [ ! -f "$CONFIG_PATH" ]; then
  echo "First run: create an OpenClaw/Codex sync pairing code in the web console."
  printf "Pairing code: "
  IFS= read -r PAIR_CODE
  if [ -z "$PAIR_CODE" ]; then
    echo "Pairing code is required on first run." >&2
    exit 1
  fi

  if [ -n "$CLAUDE_CODE_ROOT" ]; then
    node "$AGENT" pair --server "$SERVER_URL" --code "$PAIR_CODE" --openclaw-root "$OPENCLAW_ROOT" --codex-root "$CODEX_ROOT" --claude-code-root "$CLAUDE_CODE_ROOT"
  else
    node "$AGENT" pair --server "$SERVER_URL" --code "$PAIR_CODE" --openclaw-root "$OPENCLAW_ROOT" --codex-root "$CODEX_ROOT"
  fi
else
  echo "Existing pairing config found; pairing step skipped."
fi

case "${1:-}" in
  full-rebuild|rebuild-all)
    echo
    echo "Full rebuild requested. This removes safety limits and can be heavy."
    node "$AGENT" full-rebuild --delay-ms "$SAFE_DELAY_MS"
    ;;
  watch-only)
    echo
    echo "Watching for new local conversations. Press Ctrl+C to stop."
    node "$AGENT" run $RECENT_ARGS --skip-initial-scan
    ;;
  recent-only)
    echo
    echo "Importing recent local history in safe mode..."
    node "$AGENT" rebuild $RECENT_ARGS
    ;;
  rebuild-only|once)
    echo
    echo "Backfilling all local history in safe mode..."
    node "$AGENT" rebuild $SAFE_BACKFILL_ARGS
    ;;
  resync-safe)
    echo
    echo "Resetting local sync state and backfilling all local history in safe mode..."
    node "$AGENT" rebuild $SAFE_BACKFILL_ARGS --reset-state
    ;;
  "")
    echo
    echo "Backfilling all local history in safe mode..."
    node "$AGENT" rebuild $SAFE_BACKFILL_ARGS
    echo
    echo "Watching for new local conversations. Press Ctrl+C to stop."
    node "$AGENT" run $RECENT_ARGS --skip-initial-scan
    ;;
  *)
    echo "Unknown command: $1" >&2
    echo "Run: sh sync-local-macos.sh help" >&2
    exit 1
    ;;
esac

echo
echo "Local sync finished."
