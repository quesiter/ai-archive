# macOS 本地同步代理

这个便携包用于把 MacBook 上的 Codex、OpenClaw、Claude Code 本地会话同步到 AI Conversation Archive。Intel 芯片和 Apple Silicon 都可以使用，要求 Node.js 22 或更新版本。

## 首次使用

1. 在 Web 后台的设备页面生成 `OpenClaw/Codex 同步代理` 配对码。
2. 把 `ai-conversation-archive-macos-sync-0.2.20.tar.gz` 复制到 MacBook。
3. 解压并进入目录：

```sh
tar -xzf ai-conversation-archive-macos-sync-0.2.20.tar.gz
cd macos-sync-0.2.20
```

4. 补传全部安全范围内的历史会话，然后持续监听新增会话：

```sh
sh sync-local-macos.sh
```

如果已经用旧版同步过，但后台明显缺很多 OpenClaw 会话，建议执行一次：

```sh
sh sync-local-macos.sh resync-safe
```

`resync-safe` 会重置本机同步状态，重新评估全部本地历史；仍会跳过单文件超过 50 MB 或单会话超过 12000 条消息的极大文件。

## 默认路径

- Codex：`$HOME/.codex`
- OpenClaw：`$HOME/.openclaw`
- Claude Code：如果存在则读取 `$HOME/.claude`
- 配置：`$HOME/.config/ai-archive/openclaw-sync.json`
- 服务端：`https://ai-archive.gyee.tech:18443`

## 常用命令

```sh
sh sync-local-macos.sh rebuild-only
```

只补传全部安全范围内的历史，不持续监听。

```sh
sh sync-local-macos.sh recent-only
```

只导入最近 14 天、最多 500 个文件。

```sh
sh sync-local-macos.sh watch-only
```

只监听未来新增或修改的会话。

```sh
sh sync-local-macos.sh full-rebuild
```

不带安全限制地完整重建导入，可能明显占用 MacBook、网络和 NAS 资源。

## 路径或服务器覆盖

```sh
AI_ARCHIVE_SERVER="http://你的NAS-IP:18080" sh sync-local-macos.sh
```

```sh
AI_ARCHIVE_CODEX_ROOT="/path/to/.codex" \
AI_ARCHIVE_OPENCLAW_ROOT="/path/to/.openclaw" \
sh sync-local-macos.sh resync-safe
```

重新配对：

```sh
rm -f "$HOME/.config/ai-archive/openclaw-sync.json"
sh sync-local-macos.sh
```
