export const APP_VERSION = "V2.1.2";
